CMAKE_AUTOGEN_USE_SYSTEM_INCLUDE
--------------------------------

.. versionadded:: 3.27

This variable is used to initialize the :prop_tgt:`AUTOGEN_USE_SYSTEM_INCLUDE`
property on all targets as they are created.  See that target property for
additional information.

By default ``CMAKE_AUTOGEN_USE_SYSTEM_INCLUDE`` is unset.
