CMAKE_AIX_EXPORT_ALL_SYMBOLS
----------------------------

.. versionadded:: 3.17

Default value for :prop_tgt:`AIX_EXPORT_ALL_SYMBOLS` target property.
This variable is used to initialize the property on each target as it is
created.
