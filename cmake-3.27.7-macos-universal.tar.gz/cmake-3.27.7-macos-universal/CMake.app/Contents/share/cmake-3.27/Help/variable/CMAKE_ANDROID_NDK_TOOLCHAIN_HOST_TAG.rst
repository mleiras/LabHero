CMAKE_ANDROID_NDK_TOOLCHAIN_HOST_TAG
------------------------------------

.. versionadded:: 3.7.1

When :ref:`Cross Compiling for Android with the NDK`, this variable
provides the NDK's "host tag" used to construct the path to prebuilt
toolchains that run on the host.
